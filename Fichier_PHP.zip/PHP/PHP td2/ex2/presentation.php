<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Ma présentation</title>
</head>
<body>

<?php
// Variables
$prenom = "Imane";

$langages = array(
    "C",
    "PHP",
    "HTML",
    "CSS",
    "JavaScript"
);

// Tableau langage 
$niveau = array(
    "C" => 2,
    "PHP" => 4,
    "HTML" => 5,
    "CSS" => 4,
    "JavaScript" => 3
);

// Titre
echo "<h2>Ma présentation</h2>";

// Prénom
echo "Bonjour, je m'appelle $prenom et j'ai saisie BTS SIO.";
<br>

// Nombre de langages
$nb = count($langages);

// Niveau
if ($nb < 3) {
    echo "Je suis débutant.";
    <br>
} elseif ($nb <= 4) {
    echo "Je suis débrouillé.";
    <br>
} else {
    echo "Je suis aguerri.";
    <br>
}

echo "Je suis programmeur junior, je connais $nb langages de programmation :";
<br>

// Affichage 
echo "<ul>";
foreach ($langages as $lang) {
    echo "<li>$lang : niveau " . $niveau[$lang] . "</li>";
}
echo "</ul>";
?>

</body>
</html>