<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Table de multiplication</title>
</head>
<body>

<?php
// Déclaration de la variable
$chiffre = 7;

echo "<h2>La table de $chiffre</h2>";

// Boucle pour afficher la table de multiplication
for ($i = 1; $i <= 10; $i++) {
    echo "$chiffre x $i = " . ($chiffre * $i) . "<br>";
}
?>

</body>
</html>