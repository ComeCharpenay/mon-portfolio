<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Tableau Clients</title>
</head>
<body>

<?php

echo "Liste Des Clients :"

$clients = array(
    array('Nom' => 'Zette', 'Prenom' => 'Annie', 'Ville' => 'Paris'),
    array('Nom' => 'Créyon', 'Prenom' => 'Mina', 'Ville' => 'Lyon'),
    array('Nom' => 'Gator', 'Prenom' => 'Ali', 'Ville' => 'Marseille')
)

?>

</body>
</html>