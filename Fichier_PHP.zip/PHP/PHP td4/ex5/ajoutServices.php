<?php
// Connexion à la base de données
$connexion_base_donnees = mysqli_connect("localhost", "root", "", "ma_base");

// Vérification de la connexion
if (!$connexion_base_donnees) {  // ! opération négative
    die("Erreur de connexion à la base de données"); //die arrete le programme
}

// Traitement de l'ajout du service
if (isset($_POST['code']) && isset($_POST['designation'])) { // isset vérifie que les champs sont remplis
    $code_service = $_POST['code'];
    $designation_service = $_POST['designation'];

    $requete_insertion = "INSERT INTO service(code, designation) VALUES('$code_service', '$designation_service')";
    mysqli_query($connexion_base_donnees, $requete_insertion); //requete myslq à la bdd
} 

// Récupération des services existants
$requete_selection = "SELECT * FROM service";
$resultat_services = mysqli_query($connexion_base_donnees, $requete_selection);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Gestion des services</title>
</head>
<body>

<h2>Liste des services</h2>
<table border="1">
    <tr>
        <th>Code</th>
        <th>Désignation</th>
    </tr>

    <?php
    while ($ligne_service = mysqli_fetch_assoc($resultat_services)) { // recupere les lignes de resultat sous forme de tableau
        echo "<tr>";
        echo "<td>" . $ligne_service['code'] . "</td>";
        echo "<td>" . $ligne_service['designation'] . "</td>";
        echo "</tr>";
    }
    ?>
</table>

<h2>Ajout d'un service</h2>
<form method="post">
    Code : <input type="text" name="code"><br><br>
    Désignation : <input type="text" name="designation"><br><br>
    <input type="submit" value="Ajouter le service">
</form>

</body>
</html>