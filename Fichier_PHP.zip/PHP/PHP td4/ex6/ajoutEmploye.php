<?php
// Connexion à la base de données
$connexion_base_donnees = mysqli_connect("localhost", "root", "", "ma_base");

if (!$connexion_base_donnees) {
    die("Erreur de connexion");
}

// Récupération des services pour la liste déroulante
$requete_services = "SELECT * FROM service";
$resultat_services = mysqli_query($connexion_base_donnees, $requete_services);

// Traitement du formulaire
$message = ""; // initialisation variable

if (
    isset($_POST['matricule']) 
    &&
    isset($_POST['nom']) 
    &&
    isset($_POST['prenom']) 
    &&
    isset($_POST['service'])
) {
    $matricule = $_POST['matricule'];
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $service = $_POST['service'];

// Case à cocher (cadre)
if (isset($_POST['cadre'])) {
    $cadre = 1;
} else {
    $cadre = 0;
}

    // Vérification que tout est rempli
    if ($matricule != "" && $nom != "" && $prenom != "" && $service != "") {

        $requete_insertion = "INSERT INTO employe(matricule, nom, prenom, cadre, code_service)
                              VALUES('$matricule', '$nom', '$prenom', $cadre, '$service')";

        mysqli_query($connexion_base_donnees, $requete_insertion);

        $message = "L'ajout a réussi !";
    } else {
        $message = "Tous les champs sont obligatoire !";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Ajout d'un employé</title>
</head>
<body>

<h2>Ajout d'un employé</h2>

<form method="post">
    Matricule : <input type="text" name="matricule"><br><br>
    Nom : <input type="text" name="nom"><br><br>
    Prénom : <input type="text" name="prenom"><br><br>

    Cadre ? <input type="checkbox" name="cadre"><br><br>

    Service :
    <select name="service">
        <?php
        while ($ligne_service = mysqli_fetch_assoc($resultat_services)) { 
            echo "<option value='".$ligne_service['code']."'>";
            echo $ligne_service['designation'];
            echo "</option>";
        }
        ?>
    </select><br><br>

    <input type="submit" value="Ajouter l'employé">
</form>

<p><?php echo $message; ?></p>

</body>
</html>