<?php
// Connexion
$hote = 'localhost';
$base = 'votre_base';
$utilisateur = 'root';
$motDePasse = '';

try { // essayons de faire ça sinon faire la requête catch
    $connexion = new PDO("mysql:host=$hote;dbname=$base;charset=utf8", $utilisateur, $motDePasse);
} catch (PDOException $erreur) {
    die("Erreur : " . $erreur->getMessage());  //die arrete le programme en cours 
}

// Requête
$requete = "SELECT matricule, nom, prenom FROM employes"; 
$reponse = $connexion->query($requete); //demande requete sql a la base de donnée pour avoir la reponse

// Récupération
$listeEmployes = $reponse->fetchAll(); //récupérer toutes les données envoyées par la base de données et à les mettre dans un tableau PHP

// Comptage
$nombreEmployes = count($listeEmployes);

// Affichage
echo "Tableau des employés<br><br>";

echo "<table border='1'>"; // bordure tableau
echo "<tr><th>Matricule</th><th>Nom</th><th>Prénom</th></tr>";

foreach ($listeEmployes as $employe) {  //parcourir l'élément employee du tableau listeemployes
    echo "<tr>";
    echo "<td>" . $employe['matricule'] . "</td>";
    echo "<td>" . $employe['nom'] . "</td>";
    echo "<td>" . $employe['prenom'] . "</td>";
    echo "</tr>";
}

echo "</table><br>";
echo "Total : $nombreEmployes employé(s)";
?>