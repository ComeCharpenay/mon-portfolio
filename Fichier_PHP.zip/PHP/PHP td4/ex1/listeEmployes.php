<?php
// Connexion
$hote = 'localhost';
$base = 'votre_base';
$utilisateur = 'root';
$motDePasse = '';

try { // essayons de faire ça sinon faire la requête catch
    $connexion = new PDO("mysql:host=$hote;dbname=$base;charset=utf8", $utilisateur, $motDePasse);
} catch (PDOException $erreur) {
    die("Erreur : " . $erreur->getMessage()); //die arrete le programme en cours 
}

// Requête
$requete = "SELECT nom, prenom FROM employes";
$reponse = $connexion->query($requete); //demande requete sql a la base de donnée pour avoir la reponse

// Récupération des données
$listeEmployes = $reponse->fetchAll();

// Comptage
$nombreEmployes = count($listeEmployes);

// Affichage
echo "Liste des employés<br>";

foreach ($listeEmployes as $employe) {  //parcourir l'élément employee du tableau listeemployes
    echo $employe['nom'] . " " . $employe['prenom'] . "<br>"; //concaténer avec le . et ajouter un espace entre nom et prénom
}

echo "Total : $nombreEmployes employé(s)";
?>