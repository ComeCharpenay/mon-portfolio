<?php
// Connexion
$host = 'localhost';
$dbname = 'votre_base_de_donnees';
$user = 'root';
$pass = '';

try {
    // Connexion avec PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Récupération des services pour la liste déroulante
    $query = "SELECT id, nom FROM services ORDER BY nom ASC";
    $stmt = $pdo->query($query);
    $services = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage()); // Message Erreur
}

?>

<-- Formulaire Html --!>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Sélection du service</title>
</head>
<body>

    <h1>Choix d'un service</h1>

    <form action="affichage_employes.php" method="POST">
        <label for="service-select">Service :</label>
        <select name="id_service" id="service-select">
            <option value="">--Veuillez choisir un service--</option>
            
            <?php foreach ($services as $service): ?>
                <option value="<?php echo htmlspecialchars($service['id']); ?>">
                    <?php echo htmlspecialchars($service['nom']); ?>
                </option>
            <?php endforeach; ?>
            
        </select>
        
        <br><br>
        
        <button type="submit">Afficher les employés</button>
    </form>

</body>
</html>