<?php

function getBdd()
{
    // Connexion
    $hote = 'localhost';
    $base = 'votre_base';
    $utilisateur = 'root';
    $motDePasse = '';

    try { // essayons de faire ça sinon faire la requête catch
        $connexion = new PDO("mysql:host=$hote;dbname=$base;charset=utf8", $utilisateur, $motDePasse);
        return $connexion;
    } catch (PDOException $erreur) {
        die("Erreur : " . $erreur->getMessage());  //die arrete le programme en cours 
    }
}

?>