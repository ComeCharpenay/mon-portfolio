<?php
// fonctions.php

// Connexion à la base de données via PDO
function getBdd() {
    try {
        $bdd = new PDO(
            'mysql:host=localhost;dbname=monsite;charset=utf8', 
            'monsite_util', 
            'secret',
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        return $bdd;
    } catch (Exception $e) {
        die('Erreur de connexion : ' . $e->getMessage());
    }
}

// Fonction pour sécuriser l'affichage des variables (utilisée dans vos pages)
function escape($valeur) {
    return htmlspecialchars($valeur, ENT_QUOTES, 'UTF-8');
}