CREATE DATABASE IF NOT EXISTS monsite
CHARACTER SET utf8
COLLATE utf8_unicode_ci;

USE monsite;

GRANT ALL PRIVILEGES ON monsite.* 
TO 'monsite_util'@'localhost'
IDENTIFIED BY 'secret';

DROP TABLE IF EXISTS utilis;

CREATE TABLE utilis (
    NumUtil INTEGER NOT NULL AUTO_INCREMENT,
    NomUtil VARCHAR(30) NOT NULL,
    PrenomUtil VARCHAR(30) NOT NULL,
    LoginUtil VARCHAR(10) NOT NULL,
    PassUtil VARCHAR(10) NOT NULL,
    PRIMARY KEY (NumUtil)
) ENGINE=InnoDB
CHARACTER SET utf8
COLLATE utf8_unicode_ci;

INSERT INTO utilis (NomUtil, PrenomUtil, LoginUtil, PassUtil)
VALUES ('Alizan', 'Gaspar', 'galiz', 'azerty');

INSERT INTO utilis (NomUtil, PrenomUtil, LoginUtil, PassUtil)
VALUES ('Diossy', 'Daisy', 'ddios', '12345');