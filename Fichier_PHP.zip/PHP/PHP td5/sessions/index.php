<?php
session_start(); // Requis pour accéder aux variables de session
?>
<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Page d'accueil</title>
</head>
<body>
    <h1>Bienvenue sur la page d'accueil</h1>

    <?php
    // On vérifie que l'utilisateur s'est bien connecté
    if (isset($_SESSION['nom']) && isset($_SESSION['prenom'])) {
        
        // AMÉLIORATION DEMANDÉE : Affichage du prénom et du nom à la place du login/mdp
        echo "<p>Bonjour " . htmlspecialchars($_SESSION['prenom']) . " " . htmlspecialchars($_SESSION['nom']) . " !</p>";
        
        echo '<p><a href="login.php">Retourner au formulaire de connexion</a></p>';
    } else {
        // Si quelqu'un essaie d'accéder à index.php directement sans se connecter
        echo "<p>Accès restreint. Veuillez vous connecter d'abord.</p>";
        echo '<p><a href="login.php">Se connecter</a></p>';
    }
    ?>
</body>
</html>