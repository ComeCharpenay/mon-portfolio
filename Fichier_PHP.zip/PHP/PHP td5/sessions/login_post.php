<?php
session_start(); // Démarrage de la session

$messageErreur = ""; // Contiendra le détail de l'erreur (login inconnu ou mdp incorrect)

if (isset($_POST['login']) && isset($_POST['mdp'])) {
    require 'fonctions.php';
    $bdd = getBdd();

    $login = $_POST['login'];
    $mdp = $_POST['mdp'];

    // ÉTAPE 1 : On cherche l'utilisateur uniquement par son login pour vérifier s'il existe
    $requete = "SELECT * FROM utilis WHERE LoginUtil = ?";
    $resultat = $bdd->prepare($requete);
    $resultat->execute(array($login));
    
    $utilisateur = $resultat->fetch(PDO::FETCH_ASSOC);

    if ($utilisateur) {
        // ÉTAPE 2 : Le login existe, on valide le mot de passe
        if ($utilisateur['PassUtil'] === $mdp) {
            
            $authOK = true; // L'authentification est réussie
            
            // On enregistre les données requises pour la page d'accueil
            $_SESSION['login'] = $utilisateur['LoginUtil'];
            $_SESSION['nom'] = $utilisateur['NomUtil'];
            $_SESSION['prenom'] = $utilisateur['PrenomUtil'];
            
        } else {
            // Le login est bon mais le mot de passe est faux (Demande 2 du sujet)
            $messageErreur = "mot de passe incorrect.";
        }
    } else {
        // Le login n'existe pas dans la base (Demande 2 du sujet)
        $messageErreur = "login inconnu.";
    }
}
?>
<!doctype html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Résultat de l'authentification</title>
</head>
<body>
    <h1>Résultat de l'authentification</h1>

<?php
if (isset($authOK)) {
    // Affichage de confirmation avec le login
    echo "<p>Vous avez été reconnu(e) en tant que " . htmlspecialchars($login) . "</p>";
    echo '<p><a href="index.php">Poursuivre vers la page d\'accueil</a></p>';
}
else {
?>
    <p>Vous n'avez pas été reconnu(e) : <?php echo htmlspecialchars($messageErreur); ?></p>
    <p><a href="login.php">Nouvel essai</a></p>
<?php
}
?>
</body>
</html>