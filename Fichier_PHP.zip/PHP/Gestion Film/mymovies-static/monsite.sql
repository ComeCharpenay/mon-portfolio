USE monsite;

CREATE TABLE IF NOT EXISTS films (
    NumFilm integer NOT NULL AUTO_INCREMENT,
    TitreFilm varchar(100) NOT NULL,
    DescriptionFilm text NOT NULL,
    AfficheFilm varchar(255) DEFAULT 'default.jpg',
    PRIMARY KEY (NumFilm)
) ENGINE=InnoDB CHARACTER SET utf8 COLLATE utf8_unicode_ci;

-- Insertion des 3 films initiaux pour correspondre à l'accueil
INSERT INTO films (TitreFilm, DescriptionFilm, AfficheFilm) VALUES 
('Babysitting', "Babysitting est un film français réalisé par Philippe Lacheau et Nicolas Benamou, sorti en 2014. Il s'agit du premier film interprété par une grande partie de La Bande à Fifi, troupe révélée par Canal+. C'est le premier film français à allier prises de vues traditionnelles et found footage, à l'image de Projet X.", 'babysitting.jpg'),
('Vice-Versa', "Vice-versa ou Sans dessus dessous au Québec (Inside Out) est le 133e long-métrage d'animation des studios Disney et le 15e long-métrage de Pixar. Réalisé en images de synthèse par Pete Docter et Ronnie del Carmen, il est sorti en 2015.", 'viceversa.jpg'),
('Le Loup de Wall Street', "Le Loup de Wall Street (The Wolf of Wall Street) est un film américain réalisé par Martin Scorsese sorti en 2013. Adaptation de l'autobiographie éponyme de Jordan Belfort, il s'agit du plus gros succès commercial de Martin Scorsese.", 'wolf.jpg');