<?php
session_start();
require 'fonctions.php';

$bdd = getBdd();
$idFilm = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Récupération du film spécifique
$requete = $bdd->prepare("SELECT * FROM films WHERE NumFilm = ?");
$requete->execute([$idFilm]);
$film = $requete->fetch(PDO::FETCH_ASSOC);

// Si le film n'existe pas, on redirige vers l'accueil
if (!$film) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>MyMovies - <?php echo htmlspecialchars($film['TitreFilm']); ?></title>
    <link rel="stylesheet" href="lib/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="index.php">MyMovies</a>
        </div>
    </nav>

    <main class="container my-5">
        <div class="row">
            <div class="col-md-8">
                <h1 class="mb-4"><?php echo htmlspecialchars($film['TitreFilm']); ?></h1>
                <p><strong>Synopsis :</strong></p>
                <p><?php echo htmlspecialchars($film['DescriptionFilm']); ?></p>
                <p class="mt-4"><a href="index.php" class="btn btn-secondary">Retour à la liste</a></p>
            </div>
            <div class="col-md-4 text-center">
                <img src="images/<?php echo htmlspecialchars($film['AfficheFilm']); ?>" alt="Affiche" class="img-fluid rounded shadow" onerror="this.src='images/default.jpg';">
            </div>
        </div>
    </main>
</body>
</html>
