<?php
session_start();
require 'fonctions.php';
$bdd = getBdd();

// Récupération de tous les films de la base de données
$requete = $bdd->query("SELECT * FROM films ORDER BY NumFilm DESC");
$films = $requete->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MyMovies - Accueil</title>
    <link rel="stylesheet" href="lib/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="index.php">MyMovies</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="add_movie.php">Ajouter un film</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <?php if (isset($_SESSION['prenom'])): ?>
                                Bonjour, <?php echo htmlspecialchars($_SESSION['prenom'] . " " . $_SESSION['nom']); ?>
                            <?php else: ?>
                                Non connecté
                            <?php endif; ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdownMenuLink">
                            <?php if (isset($_SESSION['prenom'])): ?>
                                <li><a class="dropdown-item" href="logout.php">Se déconnecter</a></li>
                            <?php else: ?>
                                <li><a class="dropdown-item" href="login.php">Se connecter</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <main class="container my-5">
        <div class="row">
            <div class="col-12">
                
                <?php foreach ($films as $film): ?>
                    <article class="movie-item mb-5">
                        <h2><a href="movie.php?id=<?php echo $film['NumFilm']; ?>" class="text-decoration-none"><?php echo htmlspecialchars($film['TitreFilm']); ?></a></h2>
                        <p><?php echo htmlspecialchars($film['DescriptionFilm']); ?></p>
                    </article>
                <?php endforeach; ?>

            </div>
        </div>
    </main>

    <footer class="bg-light text-center py-4 border-top mt-auto">
        <div class="container">
            <p class="mb-0">Construit par <strong>XXX</strong></p>
        </div>
    </footer>

    <script src="lib/jquery/jquery.min.js"></script>
    <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>