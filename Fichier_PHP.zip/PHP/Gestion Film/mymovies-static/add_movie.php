<?php
session_start();
require 'fonctions.php';

$erreur = "";

// Traitement du formulaire lors de la soumission
if (isset($_POST['titre']) && isset($_POST['description'])) {
    $titre = trim($_POST['titre']);
    $description = trim($_POST['description']);
    
    if (!empty($titre) && !empty($description)) {
        $bdd = getBdd();
        $requete = $bdd->prepare("INSERT INTO films (TitreFilm, DescriptionFilm) VALUES (?, ?)");
        $requete->execute([$titre, $description]);
        
        // Redirection vers l'accueil après l'ajout
        header("Location: index.php");
        exit();
    } else {
        $erreur = "Veuillez remplir tous les champs.";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>MyMovies - Ajouter un film</title>
    <link rel="stylesheet" href="lib/bootstrap/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-5">
        <h1 class="mb-4">Ajouter un nouveau film</h1>
        
        <?php if (!empty($erreur)): ?>
            <div class="alert alert-danger"><?php echo $erreur; ?></div>
        <?php endif; ?>

        <form action="add_movie.php" method="post" class="w-50">
            <div class="mb-3">
                <label for="titre" class="form-label">Titre du film :</label>
                <input type="text" name="titre" id="titre" class="form-control" required />
            </div>
            <div class="mb-3">
                <label for="description" class="form-label">Description / Synopsis :</label>
                <textarea name="description" id="description" rows="5" class="form-control" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Enregistrer le film</button>
            <a href="index.php" class="btn btn-secondary text-decoration-none">Annuler</a>
        </form>
    </div>
</body>
</html>