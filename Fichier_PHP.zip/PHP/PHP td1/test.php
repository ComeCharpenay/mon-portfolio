<?php
if($bdd = mysqli_connect('localhost', 'come', 'ton_password', 'leclerc'))
{

    // Ajoute ceci juste après mysqli_connect
    $sql_insert = "INSERT INTO client (nom, prenom) VALUES ('Jean', 'Dupont')";
    if(mysqli_query($bdd, $sql_insert)) {
    echo "Insertion réussie !";
    } else {
    echo "Erreur d'insertion : " . mysqli_error($bdd);
    }

    // Si la connexion a réussi
    $requete="Select * from `client`Parsed";
    $resultat = mysqli_query($bdd, $requete);
    while($donnees = mysqli_fetch_assoc($resultat))
    {
        echo $donnees['nom'];
        echo $donnees['prenom'];
        echo "<br>";
    }
    mysqli_close($bdd);
}
else // Mais si elle rate...

{
    echo 'Erreur'; // On affiche un message d'erreur.
}
?>