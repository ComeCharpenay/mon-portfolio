<!doctype html>
<html>

<head>
    <meta charset="utf-8" />
    <title>Ma page de présentation</title>
</head>

<body>
    <h1>Ma présentation</h1>

    <?php 
    // On récupère les variables définies dans l'autre fichier
    include 'variables.php'; 
    ?>

    <p>
        <?php
        // Correction : Utilisation de guillemets doubles pour afficher les variables
        echo "Bonjour, je m'appelle $prenom et je suis en $classe."; 
        ?>
        <br>
        <?php
        // Correction : Utilisation du point (.) pour la concaténation au lieu du (+)
        echo 'Je connais ' . $nbLangages . ' langages de programmation';
        ?>
    </p>
</body>

</html>