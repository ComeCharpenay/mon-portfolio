<?php
$prixHT = 100;
$tva = 0.196;

$montantTVA = $prixHT * $tva;
$prixTTC = $prixHT + $montantTVA;
?>

<!DOCTYPE html>
<html>
<head>
    <title>Calcul de TVA</title>
</head>
<body>
    <h1>Calcul de TVA</h1>
    <ul>
        <li>Prix hors taxes : <?php echo $prixHT; ?> €</li>
        <li>Prix de TVA : <?php echo $montantTVA; ?> €</li>
        <li>Prix TTC : <?php echo $prixTTC; ?> €</li>
    </ul>
</body>
</html>