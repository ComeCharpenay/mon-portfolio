<!DOCTYPE html>
<html>
    
<?php
$prenom = "Baptiste";
$age = 39;
?>


<head>
    <title>La page de <?php echo $prenom; ?></title>
</head>
<body>
    <h1>Bienvenue !</h1>
    <p>Bonjour, je m'appelle <?php echo $prenom; ?> et j'ai <?php echo $age; ?> ans.</p>
</body>
</html>