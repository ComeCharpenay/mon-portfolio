<?php
//méthode get pour recupérer l'identifiant
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    echo "<p>Identifiant de l'employé : " . $id ."</p>";
} else {
    echo "<p>Aucun identifiant</p>";
}
?>

