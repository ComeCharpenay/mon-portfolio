<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Employées</title>
</head>
<body>



<?php
$genre
$prenom


echo "Salut $genre $prenom !"


?>


</body>
</html>
<!DOCTYPE html>